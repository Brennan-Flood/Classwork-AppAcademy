FactoryBot.define do
  factory :user do
    username {|n| Faker::Superhero.name  }
    password {|p| Faker::Internet.password }
    # association 
  end
end